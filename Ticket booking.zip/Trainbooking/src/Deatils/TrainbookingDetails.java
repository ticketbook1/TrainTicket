package Deatils;
import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TrainbookingDetails {
	String username;
	int TrainNo;
	Date date;
	TrainbookingDetails(){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter user name");
		username=sc.next();
		System.out.println("enter train no");
		TrainNo=sc.nextInt();
		System.out.println("enter date dd-MM-yyyy");
		String dateInput=sc.next();
		SimpleDateFormat dateformat=new SimpleDateFormat("dd-MM-yyyy");
		try {
			date=dateformat.parse(dateInput);
		}catch(ParseException e) {
			e.printStackTrace();
		}
	}
	public boolean isavaliable(ArrayList<TrainbookingDetails>bookings,ArrayList<TrainDeatils>trains) {
		int seates=0;
		for(TrainDeatils train:trains) {
			if(train.getTrainNo()==TrainNo) 
				seates=train.getseates();
			
		}
			int booked=0;
			for(TrainbookingDetails t:bookings) {
				if(t.TrainNo==TrainNo && t.date.equals(date)) {
					booked++;
				}
			}

			return booked<seates?true:false;
	}

}
