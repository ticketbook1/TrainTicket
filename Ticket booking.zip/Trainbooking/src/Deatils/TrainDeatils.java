package Deatils;

public class TrainDeatils {
	private int TrainNo;
	private boolean sleeper;
	private int seates;
	TrainDeatils(int TrainNo,boolean sleeper,int seates){
		this.TrainNo=TrainNo;
		this.sleeper=sleeper;
		this.seates=seates;
		}
	public int getTrainNo() {
		return TrainNo;
	}
		
	public boolean sleeper() {
		return sleeper;
	}
	public int getseates() {
		return seates;
	}
	public void setTrainNo(int no) {
			TrainNo=no;
	}
	public void setsleeper(boolean ans) {
		sleeper=ans;
	}
	public void setseates(int count) {
		seates=count;
			
	}
	public void displaytraininfo() {
		System.out.println("Train nuber: "+ TrainNo + " sleeper: " + sleeper + " seates: " + seates);
	}
}


