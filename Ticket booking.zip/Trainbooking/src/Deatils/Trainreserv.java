package Deatils;
import java.util.ArrayList;
import java.util.Scanner;
public class Trainreserv {
	public static void main(String[] args) {
		ArrayList<TrainDeatils>trains=new ArrayList<TrainDeatils>();
		ArrayList<TrainbookingDetails>bookings=new ArrayList<TrainbookingDetails>();
		trains.add(new TrainDeatils(1,true,2));
		trains.add(new TrainDeatils(2,true,4));
		trains.add(new TrainDeatils(3,true,6));
		int useropt=1;
		Scanner s=new Scanner(System.in);
		for(TrainDeatils t:trains) {
			t.displaytraininfo();
		}
		while(useropt==1) {
			System.out.println("enter 1 to Book and 2 to exit");
			useropt=s.nextInt();
			if(useropt==1) {
				TrainbookingDetails booking=new TrainbookingDetails();
				if(booking.isavaliable(bookings,trains)) {
					bookings.add(booking);
					System.out.println("Your booking is conformed");
				}
				else
					System.out.println("sorry train is full");
				}
			
		}

	}
}
